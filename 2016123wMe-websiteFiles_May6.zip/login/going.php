<?php require_once 'templates/header.php';?>
	<div class="content">
     	<div class="container">
     		<div class="col-md-8 col-sm-8 col-xs-12">
     			<div class="well text-center">
				    <p>No matter what you do, no matter how many</p>
				    <p>times you screw up and think to yourself "there's</p>
				    <p>no point to carry on", no matter how many people</p>
				    <p>tell you that you can't do it - keep going. Don't</p>
				    <p>quit.</p>
     			</div>
     			<br>
     			<a class="text-center" href="http://www.cultivatinghappyness.com/" target="_blank"><h1> Cultivating Happyness</h1></a>
     			<br>
     			<div class="well text-center">
					<p>Don't quit, because a month from now you will be</p>
				    <p>that much closer to your goal than you are now.</p>
				    <p>Yesterday you said tomorrow. Make today count.</p>
     			</div>
     			
     			<br><br>
				<p class="text-center">Read More : <a target="_blank" href="http://www.cultivatinghappyness.com/2014/10/keep-going.html"> Keep Going - Cultivating Happyness </a></p>
     		</div>
     		<?php require_once 'templates/sidebar.php';?>
     		
     	</div>
    </div> <!-- /container -->
<?php require_once 'templates/footer.php';?>
	
