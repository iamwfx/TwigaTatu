<div class="clearfix"></div>
	<!-- Footer -->
    <footer>
    	<div class="container-fluid">
    		<p class="text-center">Copyright by <a href="http://twigatatunew.us-east-1.elasticbeanstalk.com" target="_blank">TwigaTatu</a>.</strong> All rights
    reserved.</p>
    	</div>
    </footer>
    <!-- /Footer -->
  </body>
</html>
<?php ob_end_flush(); ?>